#!/user/bin/env python3

from random import randint


def gcd():
    number1 = randint(0, 100)
    number2 = randint(0, 100)
    print(f"Question: {number1} {number2}")
    if number1 > number2:
        devision = number1 - number2
        while devision > 0:
            devision = number1 - number2
    else:
        devision = number2 - number1
        while devision > 0:
            devision = number2 - number1
    return devision


if __name__ == '__main__':
    gcd()
